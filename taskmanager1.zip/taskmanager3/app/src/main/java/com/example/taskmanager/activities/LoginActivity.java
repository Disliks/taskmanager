package com.example.taskmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.taskmanager.R;
import com.example.taskmanager.utils.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private CheckBox cbRemember;
    private Button btnLogin;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(this);


        if (sessionManager.isLoggedIn()) {
            startMainActivity();
        }

        initViews();
        setupListeners();
    }

    private void initViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        cbRemember = findViewById(R.id.cbRemember);
        btnLogin = findViewById(R.id.btnLogin);


        etEmail.setHint("Логин (email)");
        etPassword.setHint("Пароль");
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> attemptLogin());

        TextView tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvForgotPassword.setOnClickListener(v -> {
            Toast.makeText(this, "Обратитесь к администратору", Toast.LENGTH_SHORT).show();
        });
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty()) {
            etEmail.setError("Введите email");
            return;
        }

        if (password.isEmpty()) {
            etPassword.setError("Введите пароль");
            return;
        }

        if (isValidCredentials(email, password)) {
            String role = email.contains("tech") ? "Техник" : "Диспетчер";
            String name = role.equals("Техник") ? "Алексей Петров" : "Иван Сидоров";
            String phone = role.equals("Техник") ? "+7 999 123-45-67" : "+7 999 987-65-43";

            sessionManager.login(email, name, role, phone);
            Toast.makeText(this, "Добро пожаловать, " + name + "!", Toast.LENGTH_SHORT).show();

            startMainActivity();
        } else {
            Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidCredentials(String email, String password) {

        return email.length() > 3 && password.length() > 3;
    }

    private void startMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}