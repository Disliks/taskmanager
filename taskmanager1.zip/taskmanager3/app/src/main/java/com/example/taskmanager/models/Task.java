package com.example.taskmanager.models;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Task implements Serializable {
    private String id;
    private String title;
    private String description;
    private String address;
    private String technician;
    private String status;
    private String priority;
    private String workType;
    private Date deadline;
    private String phone;

    public Task() {}

    public Task(String id, String title, String description, String address,
                String technician, String status, String priority,
                String workType, Date deadline, String phone) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.address = address;
        this.technician = technician;
        this.status = status;
        this.priority = priority;
        this.workType = workType;
        this.deadline = deadline;
        this.phone = phone;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getAddress() { return address; }
    public String getTechnician() { return technician; }
    public String getStatus() { return status; }
    public String getPriority() { return priority; }
    public String getWorkType() { return workType; }
    public Date getDeadline() { return deadline; }
    public String getPhone() { return phone; }

    public void setStatus(String status) { this.status = status; }

    public String getFormattedDeadline() {
        if (deadline == null) return "Не установлен";
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
        return sdf.format(deadline);
    }

    public String getPriorityColorName() {
        switch (priority) {
            case "Высокий": return "priority_high";
            case "Средний": return "priority_medium";
            case "Низкий": return "priority_low";
            default: return "priority_medium";
        }
    }

    public String getStatusColorName() {
        switch (status) {
            case "Новая": return "status_new";
            case "В работе": return "status_in_progress";
            case "Выполнена": return "status_completed";
            case "Принята": return "status_accepted";
            default: return "status_default";
        }
    }
}