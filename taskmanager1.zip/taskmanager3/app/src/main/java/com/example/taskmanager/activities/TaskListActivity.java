package com.example.taskmanager.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.taskmanager.R;
import com.example.taskmanager.adapters.TaskAdapter;
import com.example.taskmanager.models.Task;
import com.example.taskmanager.utils.SessionManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TaskListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private List<Task> taskList = new ArrayList<>();
    private List<Task> filteredTaskList = new ArrayList<>(); // Отфильтрованный список
    private SearchView searchView;
    private Button btnFilterAll, btnFilterNew, btnFilterInProgress, btnFilterCompleted;
    private Button btnPriorityAll, btnPriorityHigh, btnPriorityMedium, btnPriorityLow;
    private FloatingActionButton fabCreate;
    private SharedPreferences sharedPreferences;
    private SimpleDateFormat dateFormat;
    private SessionManager sessionManager;

    // Текущие фильтры
    private String currentStatusFilter = "Все";
    private String currentPriorityFilter = "Все";
    private String currentSearchQuery = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        Log.d("TaskList", "=== onCreate() началось ===");

        // Инициализация
        sessionManager = new SessionManager(this);
        sharedPreferences = getSharedPreferences("tasks_pref", MODE_PRIVATE);
        dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());

        initViews();
        setupRecyclerView();
        setupFilterButtons();

        // Загрузка задач
        loadTasks();

        // Показываем Toast с количеством задач
        Toast.makeText(this, "Загружено " + taskList.size() + " задач", Toast.LENGTH_LONG).show();

        // Настраиваем FAB только для диспетчеров
        if (sessionManager.isDispatcher() || sessionManager.isManager()) {
            fabCreate.setVisibility(android.view.View.VISIBLE);
            fabCreate.setOnClickListener(v -> {
                startActivity(new Intent(this, CreateTaskActivity.class));
            });
        } else {
            fabCreate.setVisibility(android.view.View.GONE);
        }

        Log.d("TaskList", "=== onCreate() завершено ===");
    }

    private void initViews() {
        Log.d("TaskList", "initViews() началось");

        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);
        fabCreate = findViewById(R.id.fabCreate);

        // Проверяем что View найдены
        Log.d("TaskList", "recyclerView: " + (recyclerView != null ? "найден" : "НЕ НАЙДЕН"));

        // Кнопки фильтрации по статусу
        btnFilterAll = findViewById(R.id.btnFilterAll);
        btnFilterNew = findViewById(R.id.btnFilterNew);
        btnFilterInProgress = findViewById(R.id.btnFilterInProgress);
        btnFilterCompleted = findViewById(R.id.btnFilterCompleted);

        // Кнопки фильтрации по приоритету
        btnPriorityAll = findViewById(R.id.btnPriorityAll);
        btnPriorityHigh = findViewById(R.id.btnPriorityHigh);
        btnPriorityMedium = findViewById(R.id.btnPriorityMedium);
        btnPriorityLow = findViewById(R.id.btnPriorityLow);

        // Настройка поиска
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.d("TaskList", "Поиск: " + newText);
                currentSearchQuery = newText.toLowerCase();
                applyFilters();
                return false;
            }
        });

        searchView.setIconifiedByDefault(false);
        searchView.setQueryHint("Поиск по названию, адресу, технику...");

        Log.d("TaskList", "initViews() завершено");
    }

    private void setupFilterButtons() {
        Log.d("TaskList", "setupFilterButtons() началось");

        // Фильтрация по статусу
        btnFilterAll.setOnClickListener(v -> {
            Log.d("TaskList", "Фильтр: Все");
            currentStatusFilter = "Все";
            highlightStatusButton(btnFilterAll);
            applyFilters();
        });

        btnFilterNew.setOnClickListener(v -> {
            Log.d("TaskList", "Фильтр: Новые");
            currentStatusFilter = "Новая";
            highlightStatusButton(btnFilterNew);
            applyFilters();
        });

        btnFilterInProgress.setOnClickListener(v -> {
            Log.d("TaskList", "Фильтр: В работе");
            currentStatusFilter = "В работе";
            highlightStatusButton(btnFilterInProgress);
            applyFilters();
        });

        btnFilterCompleted.setOnClickListener(v -> {
            Log.d("TaskList", "Фильтр: Выполнены");
            currentStatusFilter = "Выполнена";
            highlightStatusButton(btnFilterCompleted);
            applyFilters();
        });

        // Фильтрация по приоритету
        btnPriorityAll.setOnClickListener(v -> {
            Log.d("TaskList", "Приоритет: Все");
            currentPriorityFilter = "Все";
            highlightPriorityButton(btnPriorityAll);
            applyFilters();
        });

        btnPriorityHigh.setOnClickListener(v -> {
            Log.d("TaskList", "Приоритет: Высокий");
            currentPriorityFilter = "Высокий";
            highlightPriorityButton(btnPriorityHigh);
            applyFilters();
        });

        btnPriorityMedium.setOnClickListener(v -> {
            Log.d("TaskList", "Приоритет: Средний");
            currentPriorityFilter = "Средний";
            highlightPriorityButton(btnPriorityMedium);
            applyFilters();
        });

        btnPriorityLow.setOnClickListener(v -> {
            Log.d("TaskList", "Приоритет: Низкий");
            currentPriorityFilter = "Низкий";
            highlightPriorityButton(btnPriorityLow);
            applyFilters();
        });

        // Выделяем кнопку "Все" по умолчанию
        highlightStatusButton(btnFilterAll);
        highlightPriorityButton(btnPriorityAll);

        Log.d("TaskList", "setupFilterButtons() завершено");
    }

    private void applyFilters() {
        Log.d("TaskList", "applyFilters() началось");
        Log.d("TaskList", "Статус: " + currentStatusFilter + ", Приоритет: " + currentPriorityFilter + ", Поиск: " + currentSearchQuery);

        filteredTaskList.clear();

        for (Task task : taskList) {
            boolean statusMatch = currentStatusFilter.equals("Все") ||
                    task.getStatus().equals(currentStatusFilter);

            boolean priorityMatch = currentPriorityFilter.equals("Все") ||
                    task.getPriority().equals(currentPriorityFilter);

            boolean searchMatch = currentSearchQuery.isEmpty() ||
                    task.getTitle().toLowerCase().contains(currentSearchQuery) ||
                    task.getAddress().toLowerCase().contains(currentSearchQuery) ||
                    task.getTechnician().toLowerCase().contains(currentSearchQuery);

            if (statusMatch && priorityMatch && searchMatch) {
                filteredTaskList.add(task);
            }
        }

        Log.d("TaskList", "После фильтрации задач: " + filteredTaskList.size());

        if (adapter != null) {
            adapter.updateTasks(filteredTaskList);
            Log.d("TaskList", "Адаптер обновлен");
        } else {
            Log.e("TaskList", "Адаптер NULL!");
        }

        // Показываем сообщение если нет задач
        if (filteredTaskList.isEmpty()) {
            Toast.makeText(this, "Задачи не найдены", Toast.LENGTH_SHORT).show();
        }

        Log.d("TaskList", "applyFilters() завершено");
    }

    private void highlightStatusButton(Button selectedButton) {
        if (selectedButton == null) return;

        // Сброс всех кнопок статуса
        if (btnFilterAll != null) btnFilterAll.setAlpha(0.7f);
        if (btnFilterNew != null) btnFilterNew.setAlpha(0.7f);
        if (btnFilterInProgress != null) btnFilterInProgress.setAlpha(0.7f);
        if (btnFilterCompleted != null) btnFilterCompleted.setAlpha(0.7f);

        // Выделение выбранной
        selectedButton.setAlpha(1.0f);
        selectedButton.setElevation(8f);
    }

    private void highlightPriorityButton(Button selectedButton) {
        if (selectedButton == null) return;

        // Сброс всех кнопок приоритета
        if (btnPriorityAll != null) btnPriorityAll.setAlpha(0.7f);
        if (btnPriorityHigh != null) btnPriorityHigh.setAlpha(0.7f);
        if (btnPriorityMedium != null) btnPriorityMedium.setAlpha(0.7f);
        if (btnPriorityLow != null) btnPriorityLow.setAlpha(0.7f);

        // Выделение выбранной
        selectedButton.setAlpha(1.0f);
        selectedButton.setElevation(8f);
    }

    private void setupRecyclerView() {
        Log.d("TaskList", "setupRecyclerView() началось");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new TaskAdapter(filteredTaskList, task -> {
            Log.d("TaskList", "Клик по задаче: " + task.getTitle());
            Intent intent = new Intent(this, TaskDetailActivity.class);
            intent.putExtra("TASK", task);
            startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
        Log.d("TaskList", "Адаптер установлен в RecyclerView");
        Log.d("TaskList", "setupRecyclerView() завершено");
    }

    private void loadTasks() {
        Log.d("TaskList", "=== loadTasks() началось ===");

        // Очищаем список
        taskList.clear();
        Log.d("TaskList", "Список очищен");

        // ВАЖНО: сначала всегда добавляем тестовые задачи
        addSampleTasks();
        Log.d("TaskList", "После addSampleTasks() размер: " + taskList.size());

        // Затем добавляем сохраненные задачи
        List<Task> savedTasks = loadSavedTasks();
        Log.d("TaskList", "Сохраненных задач найдено: " + (savedTasks != null ? savedTasks.size() : "NULL"));

        if (savedTasks != null && !savedTasks.isEmpty()) {
            // Добавляем только уникальные задачи
            for (Task savedTask : savedTasks) {
                boolean exists = false;
                for (Task existingTask : taskList) {
                    if (existingTask.getId().equals(savedTask.getId())) {
                        exists = true;
                        Log.d("TaskList", "Задача с ID " + savedTask.getId() + " уже существует, пропускаем");
                        break;
                    }
                }
                if (!exists) {
                    taskList.add(savedTask);
                    Log.d("TaskList", "Добавлена сохраненная задача: " + savedTask.getTitle());
                }
            }
        }

        Log.d("TaskList", "Итоговый размер taskList: " + taskList.size());

        // Применяем фильтры
        applyFilters();

        Log.d("TaskList", "=== loadTasks() завершено ===");
    }

    private List<Task> loadSavedTasks() {
        Log.d("TaskList", "loadSavedTasks() началось");
        String tasksJson = sharedPreferences.getString("saved_tasks", "[]");
        Log.d("TaskList", "JSON из SharedPreferences: " + tasksJson);

        List<Task> tasks = new ArrayList<>();

        try {
            JSONArray jsonArray = new JSONArray(tasksJson);
            Log.d("TaskList", "JSONArray создан, длина: " + jsonArray.length());

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String id = jsonObject.optString("id", "");
                String title = jsonObject.optString("title", "");
                String description = jsonObject.optString("description", "");
                String address = jsonObject.optString("address", "");
                String technician = jsonObject.optString("technician", "");
                String status = jsonObject.optString("status", "Новая");
                String priority = jsonObject.optString("priority", "Средний");
                String workType = jsonObject.optString("workType", "");
                String phone = jsonObject.optString("phone", "");

                Date deadline = null;
                String deadlineStr = jsonObject.optString("deadline", "");
                if (!deadlineStr.isEmpty()) {
                    try {
                        deadline = dateFormat.parse(deadlineStr);
                    } catch (ParseException e) {
                        Log.e("TaskList", "Ошибка парсинга даты: " + deadlineStr, e);
                        deadline = new Date();
                    }
                }

                Task task = new Task(
                        id,
                        title,
                        description,
                        address,
                        technician,
                        status,
                        priority,
                        workType,
                        deadline,
                        phone
                );
                tasks.add(task);
                Log.d("TaskList", "Загружена сохраненная задача: " + title + " (ID: " + id + ")");
            }
        } catch (JSONException e) {
            Log.e("TaskList", "Ошибка парсинга JSON: " + e.getMessage(), e);
        }

        Log.d("TaskList", "loadSavedTasks() завершено, загружено задач: " + tasks.size());
        return tasks;
    }

    private void addSampleTasks() {
        Log.d("TaskList", "addSampleTasks() началось");

        // ВСЕГДА добавляем 5 тестовых задач
        List<Task> sampleTasks = new ArrayList<>();

        sampleTasks.add(new Task(
                "1",
                "Ремонт кондиционера",
                "Необходимо заменить компрессор",
                "ул. Ленина, д. 10, кв. 5",
                "Иван Техников",
                "В работе",
                "Высокий",
                "Ремонт",
                new Date(),
                "+79991234567"
        ));

        sampleTasks.add(new Task(
                "2",
                "Установка счетчика",
                "Установить водяной счетчик",
                "пр. Мира, д. 25, кв. 12",
                "Петр Механик",
                "Новая",
                "Средний",
                "Установка",
                new Date(),
                "+79998765432"
        ));

        sampleTasks.add(new Task(
                "3",
                "Проверка проводки",
                "Проверить электропроводку в офисе",
                "ул. Советская, д. 15",
                "Алексей Электрик",
                "Выполнена",
                "Низкий",
                "Проверка",
                new Date(),
                "+79995554433"
        ));

        sampleTasks.add(new Task(
                "4",
                "Обслуживание газового котла",
                "Ежегодное техническое обслуживание",
                "ул. Центральная, д. 8, кв. 3",
                "Сергей Газовщик",
                "В работе",
                "Высокий",
                "Обслуживание",
                new Date(),
                "+79994443322"
        ));

        sampleTasks.add(new Task(
                "5",
                "Замена лампочек в подъезде",
                "Замена перегоревших лампочек",
                "ул. Школьная, д. 15",
                "Максим Электрик",
                "Новая",
                "Низкий",
                "Замена",
                new Date(),
                "+79993332211"
        ));

        // Добавляем все тестовые задачи
        for (Task task : sampleTasks) {
            taskList.add(task);
            Log.d("TaskList", "Добавлена тестовая задача: " + task.getTitle() + " (ID: " + task.getId() + ")");
        }

        Log.d("TaskList", "addSampleTasks() завершено, добавлено задач: " + sampleTasks.size());
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("TaskList", "=== onResume() началось ===");

        // При возвращении на экран обновляем список
        loadTasks();

        Log.d("TaskList", "=== onResume() завершено ===");
    }
}