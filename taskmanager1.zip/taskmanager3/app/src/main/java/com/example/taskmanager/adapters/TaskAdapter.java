package com.example.taskmanager.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.taskmanager.R;
import com.example.taskmanager.models.Task;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> implements Filterable {

    private List<Task> taskList;
    private List<Task> taskListFull; // Полный список для фильтрации
    private final OnTaskClickListener onTaskClickListener;
    private final SimpleDateFormat dateFormat;

    public interface OnTaskClickListener {
        void onTaskClick(Task task);
    }

    public TaskAdapter(List<Task> taskList, OnTaskClickListener listener) {
        this.taskList = new ArrayList<>(taskList);
        this.taskListFull = new ArrayList<>(taskList);
        this.onTaskClickListener = listener;
        this.dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);

        holder.textTitle.setText(task.getTitle());
        holder.textAddress.setText(task.getAddress());
        holder.textTechnician.setText(task.getTechnician());
        holder.textStatus.setText(task.getStatus());
        holder.textPriority.setText(task.getPriority());

        if (task.getDeadline() != null) {
            holder.textDeadline.setText(dateFormat.format(task.getDeadline()));
        } else {
            holder.textDeadline.setText("Срок не указан");
        }

        // Устанавливаем цвета в зависимости от статуса и приоритета
        setStatusColor(holder.textStatus, task.getStatus());
        setPriorityColor(holder.textPriority, task.getPriority());

        // Обработчик клика
        holder.cardView.setOnClickListener(v -> {
            if (onTaskClickListener != null) {
                onTaskClickListener.onTaskClick(task);
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    private void setStatusColor(TextView textView, String status) {
        int colorResId;

        switch (status) {
            case "Новая":
                colorResId = R.color.status_new;
                break;
            case "В работе":
                colorResId = R.color.status_in_progress;
                break;
            case "Выполнена":
                colorResId = R.color.status_completed;
                break;
            default:
                colorResId = R.color.status_new;
                break;
        }

        textView.setTextColor(textView.getContext().getResources().getColor(colorResId));
    }

    private void setPriorityColor(TextView textView, String priority) {
        int colorResId;

        switch (priority) {
            case "Высокий":
                colorResId = R.color.priority_high;
                break;
            case "Средний":
                colorResId = R.color.priority_medium;
                break;
            case "Низкий":
                colorResId = R.color.priority_low;
                break;
            default:
                colorResId = R.color.priority_medium;
                break;
        }

        textView.setTextColor(textView.getContext().getResources().getColor(colorResId));
    }

    // Метод для обновления списка задач
    public void updateTasks(List<Task> newTasks) {
        this.taskList.clear();
        this.taskList.addAll(newTasks);
        this.taskListFull.clear();
        this.taskListFull.addAll(newTasks);
        notifyDataSetChanged();
    }

    // Методы фильтрации (если нужно)
    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<Task> filteredList = new ArrayList<>();

                if (constraint == null || constraint.length() == 0) {
                    filteredList.addAll(taskListFull);
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();

                    for (Task task : taskListFull) {
                        if (task.getTitle().toLowerCase().contains(filterPattern) ||
                                task.getAddress().toLowerCase().contains(filterPattern) ||
                                task.getTechnician().toLowerCase().contains(filterPattern) ||
                                task.getDescription().toLowerCase().contains(filterPattern)) {
                            filteredList.add(task);
                        }
                    }
                }

                FilterResults results = new FilterResults();
                results.values = filteredList;
                return results;
            }

            @Override
            @SuppressWarnings("unchecked")
            protected void publishResults(CharSequence constraint, FilterResults results) {
                taskList.clear();
                taskList.addAll((List<Task>) results.values);
                notifyDataSetChanged();
            }
        };
    }

    // Метод для фильтрации по статусу
    public void filterByStatus(String status) {
        if (status.equals("Все")) {
            updateTasks(new ArrayList<>(taskListFull));
            return;
        }

        List<Task> filteredList = new ArrayList<>();
        for (Task task : taskListFull) {
            if (task.getStatus().equals(status)) {
                filteredList.add(task);
            }
        }

        taskList.clear();
        taskList.addAll(filteredList);
        notifyDataSetChanged();
    }

    // Метод для фильтрации по приоритету
    public void filterByPriority(String priority) {
        if (priority.equals("Все")) {
            updateTasks(new ArrayList<>(taskListFull));
            return;
        }

        List<Task> filteredList = new ArrayList<>();
        for (Task task : taskListFull) {
            if (task.getPriority().equals(priority)) {
                filteredList.add(task);
            }
        }

        taskList.clear();
        taskList.addAll(filteredList);
        notifyDataSetChanged();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView textTitle, textAddress, textTechnician, textStatus, textPriority, textDeadline;

        TaskViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            textTitle = itemView.findViewById(R.id.textTitle);
            textAddress = itemView.findViewById(R.id.textAddress);
            textTechnician = itemView.findViewById(R.id.textTechnician);
            textStatus = itemView.findViewById(R.id.textStatus);
            textPriority = itemView.findViewById(R.id.textPriority);
            textDeadline = itemView.findViewById(R.id.textDeadline);
        }
    }
}