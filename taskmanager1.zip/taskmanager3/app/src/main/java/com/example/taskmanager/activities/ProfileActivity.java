package com.example.taskmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast; // ДОБАВЬТЕ ЭТУ СТРОЧКУ
import androidx.appcompat.app.AppCompatActivity;
import com.example.taskmanager.R;
import com.example.taskmanager.utils.SessionManager;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvRole, tvEmail, tvPhone, tvStatsTasks, tvStatsRating;
    private Button btnLogout, btnSettings;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        sessionManager = new SessionManager(this);

        initViews();
        populateProfileData();
        setupListeners();
    }

    private void initViews() {
        tvName = findViewById(R.id.tvName);
        tvRole = findViewById(R.id.tvRole);
        tvEmail = findViewById(R.id.tvEmail);
        tvPhone = findViewById(R.id.tvPhone);
        tvStatsTasks = findViewById(R.id.tvStatsTasks);
        tvStatsRating = findViewById(R.id.tvStatsRating);

        btnLogout = findViewById(R.id.btnLogout);
        btnSettings = findViewById(R.id.btnSettings);
    }

    private void populateProfileData() {
        tvName.setText(sessionManager.getName());
        tvRole.setText(sessionManager.getRole());
        tvEmail.setText(sessionManager.getEmail());
        tvPhone.setText(sessionManager.getPhone());

        // заглушка
        tvStatsTasks.setText("47");
        tvStatsRating.setText("4.8 ★");
    }

    private void setupListeners() {
        btnSettings.setOnClickListener(v -> {
            // Настройки заглушка
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Настройки")
                    .setItems(new String[]{"Уведомления", "Темная тема", "О приложении"},
                            (dialog, which) -> {
                                String[] items = {"Уведомления", "Темная тема", "О приложении"};
                                Toast.makeText(this, items[which], Toast.LENGTH_SHORT).show();
                            })
                    .show();
        });

        btnLogout.setOnClickListener(v -> {
            sessionManager.logout();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finishAffinity();
        });
    }
}