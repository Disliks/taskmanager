package com.example.taskmanager.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.taskmanager.R;
import com.example.taskmanager.models.Task;
import java.util.ArrayList;
import java.util.List;

public class SimpleMapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_map);

        TextView tvTitle = findViewById(R.id.tvTitle);
        ImageView mapImage = findViewById(R.id.mapImage);
        LinearLayout tasksContainer = findViewById(R.id.tasksContainer);
        Button btnClose = findViewById(R.id.btnClose);

        tvTitle.setText("📍 Карта задач");

        mapImage.setImageResource(R.drawable.map_preview);

        addTaskCards(tasksContainer);

        mapImage.setOnClickListener(v -> {
            Toast.makeText(this,
                    "Это статичная карта для демонстрации\n" +
                            "В реальном приложении можно подключить Яндекс.Карты",
                    Toast.LENGTH_LONG).show();
        });

        btnClose.setOnClickListener(v -> finish());
    }

    private void addTaskCards(LinearLayout container) {
        List<Task> tasks = getSampleTasks();

        for (Task task : tasks) {
            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 0, 0, 16);
            card.setLayoutParams(params);
            card.setCardElevation(4);
            card.setRadius(8);

            LinearLayout innerLayout = new LinearLayout(this);
            innerLayout.setOrientation(LinearLayout.VERTICAL);
            innerLayout.setPadding(16, 16, 16, 16);

            TextView tvTaskTitle = new TextView(this);
            tvTaskTitle.setText(task.getTitle());
            tvTaskTitle.setTextSize(16);
            tvTaskTitle.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvAddress = new TextView(this);
            tvAddress.setText("📍 " + task.getAddress());
            tvAddress.setTextSize(14);
            tvAddress.setTextColor(getResources().getColor(R.color.textSecondary));

            LinearLayout statusLayout = new LinearLayout(this);
            statusLayout.setOrientation(LinearLayout.HORIZONTAL);

            TextView tvStatus = new TextView(this);
            tvStatus.setText(task.getStatus());
            tvStatus.setTextSize(12);
            tvStatus.setPadding(8, 4, 8, 4);
            tvStatus.setBackgroundColor(getStatusColor(task.getStatus()));
            tvStatus.setTextColor(getResources().getColor(android.R.color.white));

            TextView tvPriority = new TextView(this);
            tvPriority.setText(task.getPriority());
            tvPriority.setTextSize(12);
            tvPriority.setPadding(8, 4, 8, 4);
            tvPriority.setBackgroundColor(getPriorityColor(task.getPriority()));
            tvPriority.setTextColor(getResources().getColor(android.R.color.white));
            tvPriority.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));

            statusLayout.addView(tvStatus);
            statusLayout.addView(tvPriority);

            innerLayout.addView(tvTaskTitle);
            innerLayout.addView(tvAddress);
            innerLayout.addView(statusLayout);

            card.addView(innerLayout);
            container.addView(card);

            card.setOnClickListener(v -> {
                Toast.makeText(this,
                        "Задача: " + task.getTitle() + "\n" +
                                "Адрес: " + task.getAddress() + "\n" +
                                "Техник: " + task.getTechnician(),
                        Toast.LENGTH_LONG).show();
            });
        }
    }

    private List<Task> getSampleTasks() {
        List<Task> tasks = new ArrayList<>();
        tasks.add(new Task("1", "Ремонт кондиционера", "",
                "ул. Ленина, д. 10, кв. 5", "Иван Техников",
                "В работе", "Высокий", "Ремонт", null, "+79991234567"));
        tasks.add(new Task("2", "Установка счетчика", "",
                "пр. Мира, д. 25, кв. 12", "Петр Механик",
                "Новая", "Средний", "Установка", null, "+79998765432"));
        tasks.add(new Task("3", "Проверка проводки", "",
                "ул. Советская, д. 15", "Алексей Электрик",
                "Выполнена", "Низкий", "Проверка", null, "+79995554433"));
        return tasks;
    }

    private int getStatusColor(String status) {
        switch (status) {
            case "В работе": return 0xFF2196F3;
            case "Новая": return 0xFF9C27B0;
            case "Выполнена": return 0xFF4CAF50;
            default: return 0xFF757575;
        }
    }

    private int getPriorityColor(String priority) {
        switch (priority) {
            case "Высокий": return 0xFFF44336;
            case "Средний": return 0xFFFF9800;
            case "Низкий": return 0xFF4CAF50;
            default: return 0xFF757575;
        }
    }
}