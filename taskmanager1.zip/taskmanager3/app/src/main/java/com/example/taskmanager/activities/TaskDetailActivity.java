package com.example.taskmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.example.taskmanager.R;
import com.example.taskmanager.models.Task;
import com.example.taskmanager.utils.SessionManager;
import com.google.android.material.card.MaterialCardView;

public class TaskDetailActivity extends AppCompatActivity {

    private Task task;
    private SessionManager sessionManager;

    private TextView tvTitle, tvId, tvStatus, tvAddress, tvTechnician, tvPhone,
            tvDeadline, tvWorkType, tvDescription;
    private MaterialCardView cardPriority;
    private Button btnChangeStatus, btnAddPhoto, btnNavigate, btnComplete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);

        sessionManager = new SessionManager(this);
        task = (Task) getIntent().getSerializableExtra("TASK");

        if (task == null) {
            Toast.makeText(this, "Задача не найдена", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        populateTaskData();
        setupButtons();
    }

    private void initViews() {
        tvTitle = findViewById(R.id.tvTitle);
        tvId = findViewById(R.id.tvId);
        tvStatus = findViewById(R.id.tvStatus);
        tvAddress = findViewById(R.id.tvAddress);
        tvTechnician = findViewById(R.id.tvTechnician);
        tvPhone = findViewById(R.id.tvPhone);
        tvDeadline = findViewById(R.id.tvDeadline);
        tvWorkType = findViewById(R.id.tvWorkType);
        tvDescription = findViewById(R.id.tvDescription);
        cardPriority = findViewById(R.id.cardPriority);

        btnChangeStatus = findViewById(R.id.btnChangeStatus);
        btnAddPhoto = findViewById(R.id.btnAddPhoto);
        btnNavigate = findViewById(R.id.btnNavigate);
        btnComplete = findViewById(R.id.btnComplete);
    }

    private void populateTaskData() {
        tvTitle.setText(task.getTitle());
        tvId.setText("#" + task.getId());
        tvStatus.setText(task.getStatus());
        tvAddress.setText(task.getAddress());
        tvTechnician.setText(task.getTechnician());
        tvPhone.setText(task.getPhone());
        tvDeadline.setText(task.getFormattedDeadline());
        tvWorkType.setText(task.getWorkType());
        tvDescription.setText(task.getDescription());

        int statusColor = getStatusColor(task.getStatus());
        tvStatus.setBackgroundColor(statusColor);

        int priorityColor = getPriorityColor(task.getPriority());
        cardPriority.setCardBackgroundColor(priorityColor);
    }

    private int getStatusColor(String status) {
        switch (status) {
            case "Новая":
                return ContextCompat.getColor(this, R.color.status_new);
            case "Принята":
                return ContextCompat.getColor(this, R.color.status_in_progress);
            case "В работе":
                return ContextCompat.getColor(this, R.color.status_in_progress);
            case "Выполнена":
                return ContextCompat.getColor(this, R.color.status_completed);
            default:
                return ContextCompat.getColor(this, R.color.status_new);
        }
    }

    private int getPriorityColor(String priority) {
        switch (priority) {
            case "Высокий":
                return ContextCompat.getColor(this, R.color.priority_high);
            case "Средний":
                return ContextCompat.getColor(this, R.color.priority_medium);
            case "Низкий":
                return ContextCompat.getColor(this, R.color.priority_low);
            default:
                return ContextCompat.getColor(this, R.color.priority_medium);
        }
    }

    private void setupButtons() {
        if (sessionManager.isTechnician()) {
            btnChangeStatus.setVisibility(View.VISIBLE);
            btnAddPhoto.setVisibility(View.VISIBLE);
            btnNavigate.setVisibility(View.VISIBLE);
            btnComplete.setVisibility(View.VISIBLE);

            btnChangeStatus.setOnClickListener(v -> {
                Toast.makeText(this, "Изменение статуса", Toast.LENGTH_SHORT).show();
            });

            btnAddPhoto.setOnClickListener(v -> {
                Toast.makeText(this, "Добавление фото", Toast.LENGTH_SHORT).show();
            });

            btnNavigate.setOnClickListener(v -> {
                Toast.makeText(this, "Построение маршрута", Toast.LENGTH_SHORT).show();
            });

            btnComplete.setOnClickListener(v -> {
                task.setStatus("Выполнена");
                Toast.makeText(this, "Задача выполнена!", Toast.LENGTH_SHORT).show();
                finish();
            });
        } else {

            btnComplete.setText("ПРИНЯТЬ РАБОТУ");
            btnComplete.setVisibility(View.VISIBLE);
            btnComplete.setOnClickListener(v -> {
                task.setStatus("Принята");
                Toast.makeText(this, "Работа принята", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }
}