package com.example.taskmanager.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.taskmanager.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class CreateTaskActivity extends AppCompatActivity {

    private EditText etTitle, etDescription, etAddress, etTechnician,
            etPhone, etWorkType;
    private Button btnCreate;
    private SharedPreferences sharedPreferences;
    private Gson gson;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);

        sharedPreferences = getSharedPreferences("tasks_pref", MODE_PRIVATE);
        gson = new Gson();
        dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());



        initViews();
        setupListeners();
    }

    private void initViews() {
        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        etAddress = findViewById(R.id.etAddress);
        etTechnician = findViewById(R.id.etTechnician);
        etPhone = findViewById(R.id.etPhone);
        etWorkType = findViewById(R.id.etWorkType);
        btnCreate = findViewById(R.id.btnCreate);
    }

    private void setupListeners() {
        btnCreate.setOnClickListener(v -> {
            if (validateInputs()) {
                createNewTask();
            }
        });
    }

    private boolean validateInputs() {
        if (etTitle.getText().toString().trim().isEmpty()) {
            etTitle.setError("Введите название задачи");
            return false;
        }
        if (etAddress.getText().toString().trim().isEmpty()) {
            etAddress.setError("Введите адрес");
            return false;
        }
        return true;
    }

    private void createNewTask() {
        // Загружаем существующие задачи
        List<TaskData> existingTasks = loadExistingTasks();

        // Создаем новую задачу
        TaskData newTask = new TaskData();
        newTask.id = UUID.randomUUID().toString();
        newTask.title = etTitle.getText().toString().trim();
        newTask.description = etDescription.getText().toString().trim();
        newTask.address = etAddress.getText().toString().trim();
        newTask.technician = etTechnician.getText().toString().trim();
        newTask.status = "Новая";
        newTask.priority = "Средний";
        newTask.workType = etWorkType.getText().toString().trim();
        newTask.deadline = dateFormat.format(new Date());
        newTask.phone = etPhone.getText().toString().trim();

        // Добавляем новую задачу
        existingTasks.add(newTask);

        // Сохраняем обновленный список
        saveTasks(existingTasks);

        Toast.makeText(this, "Задача создана и сохранена!", Toast.LENGTH_SHORT).show();

        // Возвращаемся на главный экран
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private List<TaskData> loadExistingTasks() {
        String tasksJson = sharedPreferences.getString("saved_tasks", "[]");
        Type type = new TypeToken<List<TaskData>>() {}.getType();
        List<TaskData> tasks = gson.fromJson(tasksJson, type);
        return tasks != null ? tasks : new ArrayList<>();
    }

    private void saveTasks(List<TaskData> tasks) {
        String tasksJson = gson.toJson(tasks);
        sharedPreferences.edit()
                .putString("saved_tasks", tasksJson)
                .apply();
    }

    // Вспомогательный класс для сохранения
    private static class TaskData {
        String id;
        String title;
        String description;
        String address;
        String technician;
        String status;
        String priority;
        String workType;
        String deadline;
        String phone;
    }
}