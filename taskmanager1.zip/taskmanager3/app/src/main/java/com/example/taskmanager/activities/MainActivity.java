package com.example.taskmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.taskmanager.R;
import com.example.taskmanager.utils.SessionManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvWelcome, tvDate, tvStatsNew, tvStatsInProgress, tvStatsCompleted;
    private LinearLayout cvTasks, cvCreate, cvMap, cvProfile;
    private Button btnLogout;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sessionManager = new SessionManager(this);

        initViews();
        setupUI();
        setupListeners();
    }

    private void initViews() {
        tvWelcome = findViewById(R.id.tvWelcome);
        tvDate = findViewById(R.id.tvDate);
        tvStatsNew = findViewById(R.id.tvStatsNew);
        tvStatsInProgress = findViewById(R.id.tvStatsInProgress);
        tvStatsCompleted = findViewById(R.id.tvStatsCompleted);

        cvTasks = findViewById(R.id.cvTasks);
        cvCreate = findViewById(R.id.cvCreate);
        cvMap = findViewById(R.id.cvMap);
        cvProfile = findViewById(R.id.cvProfile);

        btnLogout = findViewById(R.id.btnLogout);
    }

    private void setupUI() {

        String welcome = sessionManager.isTechnician() ?
                "Привет, " + sessionManager.getName() + "!" :
                "Добрый день, " + sessionManager.getName() + "!";
        tvWelcome.setText(welcome);

        String currentDate = new SimpleDateFormat("dd MMMM yyyy", new Locale("ru")).format(new Date());
        tvDate.setText(currentDate);

        tvStatsNew.setText("5");
        tvStatsInProgress.setText("3");
        tvStatsCompleted.setText("14");


        if (sessionManager.isTechnician()) {
            cvCreate.setVisibility(View.GONE);
        }
    }

    private void setupListeners() {
        cvTasks.setOnClickListener(v -> {
            Intent intent = new Intent(this, TaskListActivity.class);
            startActivity(intent);
        });

        cvCreate.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateTaskActivity.class);
            startActivity(intent);
        });

        cvMap.setOnClickListener(v -> {
            Intent intent = new Intent(this, SimpleMapActivity.class);
            startActivity(intent);
        });


        cvProfile.setOnClickListener(v -> {
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            sessionManager.logout();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}