package com.example.taskmanager.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "TaskManagerPref";
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void login(String email, String name, String role, String phone) {
        editor.putBoolean("isLoggedIn", true);
        editor.putString("email", email);
        editor.putString("name", name);
        editor.putString("role", role);
        editor.putString("phone", phone);
        editor.apply();
    }

    public boolean loginTestUser(String email, String password) {

        if (email.equals("tech@mail.com") && password.equals("123456")) {
            login("tech@mail.com", "Иван Техников", "Техник", "+79991234567");
            return true;
        } else if (email.equals("admin@mail.com") && password.equals("admin123")) {
            login("admin@mail.com", "Анна Диспетчер", "Диспетчер", "+79998765432");
            return true;
        } else if (email.equals("manager@mail.com") && password.equals("manager123")) {
            login("manager@mail.com", "Петр Менеджер", "Менеджер", "+79995554433");
            return true;
        }
        return false;
    }

    public void createTestUsers() {

    }

    public String[] getTestUserCredentials(int userType) {
        switch (userType) {
            case 0: // Техник
                return new String[]{"tech@mail.com", "123456"};
            case 1: // Диспетчер
                return new String[]{"admin@mail.com", "admin123"};
            case 2: // Менеджер
                return new String[]{"manager@mail.com", "manager123"};
            default:
                return new String[]{"", ""};
        }
    }

    public String getTestUserDescription(int userType) {
        switch (userType) {
            case 0:
                return "Техник - tech@mail.com / 123456";
            case 1:
                return "Диспетчер - admin@mail.com / admin123";
            case 2:
                return "Менеджер - manager@mail.com / manager123";
            default:
                return "";
        }
    }

    public boolean isTestEmail(String email) {
        return email.equals("tech@mail.com") ||
                email.equals("admin@mail.com") ||
                email.equals("manager@mail.com");
    }

    public boolean isLoggedIn() {
        return pref.getBoolean("isLoggedIn", false);
    }

    public String getRole() {
        return pref.getString("role", "");
    }

    public String getName() {
        return pref.getString("name", "");
    }

    public String getEmail() {
        return pref.getString("email", "");
    }

    public String getPhone() {
        return pref.getString("phone", "");
    }

    public boolean isTechnician() {
        return "Техник".equals(getRole());
    }

    public boolean isDispatcher() {
        return "Диспетчер".equals(getRole());
    }

    public boolean isManager() {
        return "Менеджер".equals(getRole());
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}